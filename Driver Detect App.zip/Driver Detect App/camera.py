#snapshot application

from tkinter import *
import cv2
from PIL import Image, ImageTk
import time
from PyQt5.QtMultimedia import *
from PyQt5.QtCore import QUrl


#class for the app

class App:
    def __init__(self,video_source=1):
        self.appName="Snap Camera App"
        self.window = Tk()
        self.window.title(self.appName)
        self.window.resizable(0,0)
        self.window['bg']= 'black'
        self.video_source = video_source
        #photo = PhotoImage(file="shot_1299228951.png")
        #self.window.iconphoto(False, photo)

        self.vid = MyVideoCapture(self.video_source)
        self.label =Label(self.window, text= self.appName, font= 15,
                           bg='blue',fg='white').pack(side=TOP,fill=BOTH)
        #creating the canas above source video
        self.canvas = Canvas(self.window, width = self.vid.width, height = self.vid.height)
        self.canvas.pack()

        #button that lets us take a snap
        self.btn_snapshot = Button(self.window, text="Take Snapshot", width=30,bg='light blue',
                                   command=self.snapshot)
        self.btn_snapshot.pack(anchor=CENTER,expand = True)
        self.update()
        self.window.mainloop()

    def snapshot(self):
        check, frame = self.vid.getFrame()
        if check:
            image = "IMG " + time.strftime("%H-%M-%S-%d-%m")+ ".jpg"
            cv2.imwrite(image,cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
                #lets show that the image is now saved
            msg = Label(self.window,text='image is successfully saved ' + image,bg='black',fg='green').place(x=430,y=510)
            
            #add the snap shot sound effect
            file = QUrl("Camera Shutter Sound Effect.mp3")
            content = QMediaContent(file)
            self.player = QMediaPlayer()
            self.player.setMedia(content)
            self.player.play()
    def update(self):
        #get frame from the video
        isTrue, frame = self.vid.getFrame()
        if isTrue:
            self.photo = ImageTk.PhotoImage(image = Image.fromarray(frame))
            self.canvas.create_image(0,0, image = self.photo, anchor = NW)
        self.window.after(10, self.update)

#class to capture the video
class MyVideoCapture:
    def __init__(self, video_source=1):
        self.vid = cv2.VideoCapture(video_source)
        if not self.vid.isOpened():
            raise ValueError("There is an error", video_source)
        #getting video height and width
        self.width = self.vid.get(cv2.CAP_PROP_FRAME_WIDTH)
        self.height = self.vid.get(cv2.CAP_PROP_FRAME_HEIGHT)

    def getFrame(self):
        
        if self.vid.isOpened():
            isTrue, frame = self.vid.read()
            if isTrue:
                    #if isTrue is true convert the current frame to RBG
                return (isTrue, cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
            else:
                
                return (isTrue, None)
        else:
            
            return (isTrue, None)
        
           
    def __del__(self):
        if self.vid.isOpened():
            self.vid.release()


if __name__ =="__main__":
    App()
    
